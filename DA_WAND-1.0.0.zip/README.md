# DA Wand for Blender
Add-on that runs Richard Liu and 3DL's DAWand in Blender. (https://github.com/threedle/DA-Wand)


https://github.com/user-attachments/assets/b66537a4-4f9a-4595-ba66-99f2b80f24c5



## Installation
1. Code -> Download ZIP
2. Open Blender
3. Open the addons menu (Edit->Preferences->Add-ons)
4. Click 'install' in the top right
5. Click DAWand-Blender-main.zip
6. You may have to restart Blender
7. Go back to Edit->Preferences->Add-ons and search for 'DA Wand'
8. Click the check next to DA Wand
9. Click 'Install Dependencies', which will take a few minutes to install.

**Windows users:** Run Blender with administrator privileges for the install stage

## Usage
1. Load in or create a triangle mesh. (You can triangulate any mesh using Blender's 'Triangulate Faces' option.
2. Put the mesh into edit mode by pressing <kbd>tab</kbd>, or go the UV editing workspace on Blender.
3. Press <kbd>n</kbd> to open the side panel, and click 'DAWand Options' to see the rest of the settings.
4. To get DAWand, find the Wand icon in the tools in Edit mode.
5. Click on a face to select the region.
6. Then, in the right-side settings menu, you can see more options and even unwrap the mesh.


## Videos
### Selection

https://github.com/user-attachments/assets/de6b9705-f640-4ade-94eb-0bb0b9758c03


### Unwrapping and adding image textures

https://github.com/user-attachments/assets/f9b2acaa-0dc5-42f9-9b21-a801cd13ee35


### Using SLIM unwrap

https://github.com/user-attachments/assets/87a015ea-8c86-424c-953a-d9cf9027498d


## Credit  
- Code used for dependency install: https://github.com/robertguetzkow/blender-python-examples/blob/master/add_ons/install_dependencies/install_dependencies.py
- Much of the organization is based on Rignet's, so thanks to them: https://github.com/pKrime/brignet
